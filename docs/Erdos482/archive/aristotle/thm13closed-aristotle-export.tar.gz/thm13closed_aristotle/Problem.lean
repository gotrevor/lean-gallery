import Mathlib

open Real

/-
GOAL: prove Stoll [St05] Theorem 1.3's closed forms by joint induction on the recurrence.

Setup (St05 Thm 1.3, base g≥2, t = base-g mantissa of w so 1≤t<g):
  a = g/((g-1)(t+g)),  b = (g-1)(t+g)   [note a·b = g],  even-offset 1/(g-1), odd-offset ε,
  with -1/g ≤ ε < (g+1)(g-2)/g.
Recurrence (0-indexed `gu n = u_{n+1}`, u₁=1): step from index n uses (a,ε) when n is EVEN
(original odd index) and (b, 1/(g-1)) when n is ODD.

Closed forms to prove (k ≥ 0):
  gu(2k)   = g^k + ⌊t·g^k / g⌋        (= u_{2k+1}; at k=0 this is 1+⌊t/g⌋ = 1 since 1≤t<g)
  (g-1)·gu(2k+1) = g^k − 1            (= u_{2k+2} = (g^k−1)/(g-1), the geometric sum 1+g+…+g^{k-1})

PROOF STRATEGY (elementary, the heart of St05). Joint induction on k.
* Each step is a single `⌊real⌋ = integer` claim, reduced via `Int.floor_eq_iff` to two
  inequalities `W ≤ (expr) < W+1`.
* The fractional-part / digit-tail bound `0 ≤ t·g^k − g·⌊t·g^{k-1}⌋ < g` (from
  `0 ≤ ⌊g·x⌋ − g⌊x⌋ < g`) is what closes each step; combine with the parameter bounds on a,b,ε,t.
* Use a·b = g and 1 ≤ t < g freely.  No field theory, no badly-approximable input.
Take care with casts ℕ→ℤ→ℝ and with `g - 1` (use `2 ≤ g` so `g - 1 ≥ 1`, nonzero).

Helper: floor of t/g is 0 when 1 ≤ t < g and g ≥ 2
-/
private lemma floor_t_div_g_zero (g : ℕ) (hg : 2 ≤ g) (t : ℝ) (ht1 : 1 ≤ t) (ht2 : t < (g : ℝ)) :
    ⌊t * (g : ℝ) ^ 0 / (g : ℝ)⌋ = (0 : ℤ) := by
  exact Int.floor_eq_zero_iff.mpr ⟨ by positivity, by rw [ div_lt_iff₀ ( by positivity ) ] ; linarith ⟩

/-
Helper: a*(1+ε) is in [0,1) so its floor is 0, meaning gu(1) satisfies (g-1)*gu(1) = 0
-/
private lemma floor_a_one_plus_eps_zero (g : ℕ) (hg : 2 ≤ g) (t : ℝ) (ht1 : 1 ≤ t) (ht2 : t < (g : ℝ))
    (ε a : ℝ) (ha : a = (g : ℝ) / (((g : ℝ) - 1) * (t + (g : ℝ))))
    (hε0 : -1 / (g : ℝ) ≤ ε) (hε1 : ε < ((g : ℝ) + 1) * ((g : ℝ) - 2) / (g : ℝ)) :
    ⌊a * (1 + ε)⌋ = (0 : ℤ) := by
  norm_num [ ha ];
  rw [ div_mul_eq_mul_div, div_lt_one ];
  · exact ⟨ div_nonneg ( mul_nonneg ( Nat.cast_nonneg _ ) ( by rw [ div_le_iff₀ ( by positivity ) ] at *; nlinarith [ ( by norm_cast : ( 2 : ℝ ) ≤ g ) ] ) ) ( mul_nonneg ( by norm_num; linarith ) ( by linarith ) ), by rw [ lt_div_iff₀ ( by positivity ) ] at *; nlinarith [ ( by norm_cast : ( 2 : ℝ ) ≤ g ) ] ⟩;
  · nlinarith [ show ( g : ℝ ) ≥ 2 by norm_cast ]

/-
Helper: the even inductive step. Given the odd hypothesis for k, derive even for k+1.
gu(2k+2) = ⌊b * (gu(2k+1) + 1/(g-1))⌋ and (g-1)*gu(2k+1) = g^k - 1
implies gu(2(k+1)) = g^{k+1} + ⌊t*g^{k+1}/g⌋
-/
private lemma even_step (g : ℕ) (hg : 2 ≤ g) (t : ℝ) (ht1 : 1 ≤ t) (ht2 : t < (g : ℝ))
    (b : ℝ) (hb : b = ((g : ℝ) - 1) * (t + (g : ℝ)))
    (k : ℕ) (u : ℤ) (hu : ((g : ℤ) - 1) * u = (g : ℤ) ^ k - 1) :
    ⌊b * ((u : ℝ) + 1 / ((g : ℝ) - 1))⌋ = (g : ℤ) ^ (k + 1) + ⌊t * (g : ℝ) ^ (k + 1) / (g : ℝ)⌋ := by
  cases eq_or_ne ( g - 1 : ℝ ) 0 <;> simp_all +decide [ pow_succ, mul_assoc, mul_div_assoc, mul_comm ];
  · linarith [ show ( g : ℝ ) ≥ 2 by norm_cast ];
  · -- Substitute $u(g - 1) = g^k - 1$ into the expression.
    have h_sub : (t + g) * ((g - 1) * (u + 1 / (g - 1))) = (t + g) * (g^k / (g - 1) * (g - 1)) := by
      field_simp;
      norm_cast;
      grobner;
    simp_all +decide [ mul_div_cancel₀, ne_of_gt ( zero_lt_two.trans_le hg ) ];
    rw [ h_sub.resolve_right ( by positivity ) ] ; ring_nf ; norm_num [ Int.floor_eq_iff ] ;
    constructor <;> linarith [ Int.floor_le ( t * g ^ k ), Int.lt_floor_add_one ( t * g ^ k ) ]

/-
Helper: the odd inductive step. Given even for k+1, derive odd for k+1.
gu(2k+3) = ⌊a * (gu(2k+2) + ε)⌋ and gu(2k+2) = g^{k+1} + ⌊t*g^k⌋
implies (g-1)*gu(2k+3) = g^{k+1} - 1
-/
private lemma odd_step (g : ℕ) (hg : 2 ≤ g) (t : ℝ) (ht1 : 1 ≤ t) (ht2 : t < (g : ℝ))
    (ε a : ℝ) (ha : a = (g : ℝ) / (((g : ℝ) - 1) * (t + (g : ℝ))))
    (hε0 : -1 / (g : ℝ) ≤ ε) (hε1 : ε < ((g : ℝ) + 1) * ((g : ℝ) - 2) / (g : ℝ))
    (k : ℕ) :
    ((g : ℤ) - 1) * ⌊a * (((g : ℤ) ^ (k + 1) + ⌊t * (g : ℝ) ^ (k + 1) / (g : ℝ)⌋ : ℤ) + ε)⌋
      = (g : ℤ) ^ (k + 1) - 1 := by
  -- By definition of $m$, we have $m = \lfloor t * g^{k+1} / g \rfloor$, so $t * g^{k+1} / g = m + f$ where $0 \leq f < 1$.
  set m : ℤ := ⌊t * (g : ℝ) ^ (k + 1) / (g : ℝ)⌋
  set f : ℝ := t * (g : ℝ) ^ (k + 1) / (g : ℝ) - m
  have h_f : 0 ≤ f ∧ f < 1 := by
    exact ⟨ Int.fract_nonneg _, Int.fract_lt_one _ ⟩;
  -- So $a * ((g^{k+1} + m : ℤ) + ε) = N + r$ where $N = (g^{k+1}-1)/(g-1)$ and $r = 1/(g-1) + g*(ε-f)/((g-1)(t+g)) = (t+g+g*ε-g*f)/((g-1)(t+g))$.
  set N : ℤ := (g ^ (k + 1) - 1) / (g - 1)
  set r : ℝ := (t + g + g * ε - g * f) / ((g - 1) * (t + g))
  have h_expr : a * ((g ^ (k + 1) + m : ℤ) + ε) = N + r := by
    rw [ Int.cast_div ] <;> norm_num;
    · simp +zetaDelta at *;
      rw [ ha, Int.fract ];
      field_simp;
      ring;
    · exact sub_one_dvd_pow_sub_one _ _;
    · linarith [ show ( g : ℝ ) ≥ 2 by norm_cast ];
  -- We need to show that $0 \leq r < 1$.
  have h_r_bounds : 0 ≤ r ∧ r < 1 := by
    rw [ le_div_iff₀, div_lt_iff₀ ] <;> try nlinarith [ show ( g : ℝ ) ≥ 2 by norm_cast ];
    constructor <;> nlinarith [ show ( g : ℝ ) ≥ 2 by norm_cast, mul_div_cancel₀ ( ( -1 : ℝ ) ) ( by positivity : ( g : ℝ ) ≠ 0 ), mul_div_cancel₀ ( ( g + 1 : ℝ ) * ( g - 2 ) ) ( by positivity : ( g : ℝ ) ≠ 0 ) ];
  -- Therefore, $\lfloor a * ((g^{k+1} + m : ℤ) + ε) \rfloor = N$.
  have h_floor : ⌊a * ((g ^ (k + 1) + m : ℤ) + ε)⌋ = N := by
    exact Int.floor_eq_iff.mpr ⟨ by linarith, by linarith ⟩;
  rw [ h_floor, Int.mul_ediv_cancel' ( sub_one_dvd_pow_sub_one _ _ ) ]

theorem thm13_closed (g : ℕ) (hg : 2 ≤ g) (t : ℝ) (ht1 : 1 ≤ t) (ht2 : t < (g : ℝ))
    (ε a b : ℝ) (ha : a = (g : ℝ) / (((g : ℝ) - 1) * (t + g)))
    (hb : b = ((g : ℝ) - 1) * (t + g))
    (hε0 : -1 / (g : ℝ) ≤ ε) (hε1 : ε < ((g : ℝ) + 1) * ((g : ℝ) - 2) / g)
    (gu : ℕ → ℤ) (hu0 : gu 0 = 1)
    (hrec : ∀ n, gu (n + 1)
      = if Even n then ⌊a * ((gu n : ℝ) + ε)⌋ else ⌊b * ((gu n : ℝ) + 1 / ((g : ℝ) - 1))⌋) :
    (∀ k, gu (2 * k) = (g : ℤ) ^ k + ⌊t * (g : ℝ) ^ k / g⌋) ∧
      (∀ k, ((g : ℤ) - 1) * gu (2 * k + 1) = (g : ℤ) ^ k - 1) := by
  refine' ⟨ fun k => _, fun k => _ ⟩;
  · induction' k with k ih;
    · norm_num [ hu0, floor_t_div_g_zero g hg t ht1 ht2 ];
      exact ⟨ by positivity, by rwa [ div_lt_one ( by positivity ) ] ⟩;
    · convert even_step g hg t ht1 ht2 b hb k ( gu ( 2 * k + 1 ) ) _ using 1;
      · exact hrec _ ▸ if_neg ( by simp +decide );
      · induction' k with k ih;
        · norm_num [ hu0, hrec ];
          have := floor_a_one_plus_eps_zero g hg t ht1 ht2 ε a ha hε0 hε1; rw [ Int.floor_eq_iff ] at this; norm_num at * ; aesop;
        · convert odd_step g hg t ht1 ht2 ε a ha hε0 hε1 k using 1;
          rw [ ← ih, hrec ] ; norm_num [ Nat.even_add_one ];
  · induction' k with k ih;
    · norm_num [ hu0, hrec 0, ha ];
      refine' Or.inr ⟨ _, _ ⟩;
      · exact mul_nonneg ( div_nonneg ( by positivity ) ( mul_nonneg ( by norm_num; linarith ) ( by positivity ) ) ) ( by rw [ div_le_iff₀ ( by positivity ) ] at hε0; nlinarith [ ( by norm_cast : ( 2 : ℝ ) ≤ g ) ] );
      · rw [ div_mul_eq_mul_div, div_lt_iff₀ ] <;> nlinarith [ show ( g : ℝ ) ≥ 2 by norm_cast, mul_div_cancel₀ ( ( g + 1 ) * ( g - 2 ) : ℝ ) ( by positivity : ( g : ℝ ) ≠ 0 ) ];
    · convert odd_step g hg t ht1 ht2 ε a ha hε0 hε1 k using 1;
      convert congr_arg _ ( even_step g hg t ht1 ht2 b hb k ( gu ( 2 * k + 1 ) ) ih ) using 1;
      rotate_right;
      use fun x => ( g - 1 ) * ⌊a * ( x + ε ) ⌋;
      · grind;
      · norm_cast